import { useState } from 'react';
import { useAuth } from '../context/AuthContext.jsx';

export default function Auth() {
  const { signIn, signUp } = useAuth();
  const [mode, setMode] = useState('signin');
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [err, setErr] = useState('');

  const onChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const submit = (e) => {
    e.preventDefault();
    setErr('');
    try {
      if (mode === 'signin') signIn(form);
      else signUp(form);
    } catch (e) {
      setErr(e.message);
    }
  };

  return (
    <div className="auth-shell">
      <div className="auth-bg">
        <div className="blob blob-1" />
        <div className="blob blob-2" />
        <div className="blob blob-3" />
      </div>

      <div className="auth-card glass">
        <div className="brand">
          <div className="brand-mark">📚</div>
          <div>
            <h1>Assignment Tracker</h1>
            <p className="muted">Stay on top of every submission.</p>
          </div>
        </div>

        <div className="tabs">
          <button
            className={mode === 'signin' ? 'tab active' : 'tab'}
            onClick={() => setMode('signin')}
            type="button"
          >
            Sign In
          </button>
          <button
            className={mode === 'signup' ? 'tab active' : 'tab'}
            onClick={() => setMode('signup')}
            type="button"
          >
            Create Account
          </button>
          <span className={`tab-indicator ${mode}`} />
        </div>

        <form onSubmit={submit} className="form">
          {mode === 'signup' && (
            <label className="field">
              <span>Full name</span>
              <input name="name" value={form.name} onChange={onChange} required placeholder="Jane Doe" />
            </label>
          )}
          <label className="field">
            <span>Email</span>
            <input type="email" name="email" value={form.email} onChange={onChange} required placeholder="you@college.edu" />
          </label>
          <label className="field">
            <span>Password</span>
            <input type="password" name="password" value={form.password} onChange={onChange} required minLength={4} placeholder="••••••••" />
          </label>

          {err && <div className="error">{err}</div>}

          <button className="btn primary lg" type="submit">
            {mode === 'signin' ? 'Sign In' : 'Create Account'}
          </button>

          <p className="muted center small">
            {mode === 'signin' ? "New here?" : 'Already have an account?'}{' '}
            <button
              type="button"
              className="linkbtn"
              onClick={() => setMode(mode === 'signin' ? 'signup' : 'signin')}
            >
              {mode === 'signin' ? 'Create one' : 'Sign in'}
            </button>
          </p>
        </form>
      </div>
    </div>
  );
}
