import { useEffect, useMemo, useState } from 'react';
import { useAuth } from '../context/AuthContext.jsx';

const STORAGE = (email) => `ast_assignments_${email}`;

const today = () => new Date().toISOString().slice(0, 10);

function computeStatus(a) {
  if (a.status === 'Submitted') return 'Submitted';
  // auto-late if past due
  if (a.dueDate && a.dueDate < today()) return 'Late';
  return 'Pending';
}

export default function Dashboard() {
  const { user, signOut } = useAuth();
  const [assignments, setAssignments] = useState([]);
  const [form, setForm] = useState({ title: '', subject: '', dueDate: '' });
  const [filter, setFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All');
  const [showForm, setShowForm] = useState(false);

  useEffect(() => {
    const data = JSON.parse(localStorage.getItem(STORAGE(user.email)) || '[]');
    setAssignments(data);
  }, [user.email]);

  useEffect(() => {
    localStorage.setItem(STORAGE(user.email), JSON.stringify(assignments));
  }, [assignments, user.email]);

  const subjects = useMemo(
    () => Array.from(new Set(assignments.map((a) => a.subject))).sort(),
    [assignments]
  );

  const enriched = assignments.map((a) => ({ ...a, computed: computeStatus(a) }));

  const filtered = enriched.filter(
    (a) =>
      (filter === 'All' || a.subject === filter) &&
      (statusFilter === 'All' || a.computed === statusFilter)
  );

  const counts = useMemo(() => {
    const c = { total: enriched.length, Submitted: 0, Pending: 0, Late: 0 };
    enriched.forEach((a) => (c[a.computed] = (c[a.computed] || 0) + 1));
    return c;
  }, [enriched]);

  const addAssignment = (e) => {
    e.preventDefault();
    if (!form.title || !form.subject || !form.dueDate) return;
    const newItem = {
      id: crypto.randomUUID(),
      title: form.title.trim(),
      subject: form.subject.trim(),
      dueDate: form.dueDate,
      status: 'Pending',
      createdAt: Date.now(),
    };
    setAssignments([newItem, ...assignments]);
    setForm({ title: '', subject: '', dueDate: '' });
    setShowForm(false);
  };

  const setStatus = (id, status) =>
    setAssignments(assignments.map((a) => (a.id === id ? { ...a, status } : a)));

  const remove = (id) => setAssignments(assignments.filter((a) => a.id !== id));

  const pct = (n) => (counts.total ? Math.round((n / counts.total) * 100) : 0);

  return (
    <div className="app">
      <header className="topbar glass">
        <div className="brand small">
          <div className="brand-mark">📚</div>
          <div>
            <h2>Assignment Tracker</h2>
            <p className="muted small">Welcome back, {user.name}</p>
          </div>
        </div>
        <div className="row gap">
          <button className="btn primary" onClick={() => setShowForm(true)}>+ New Assignment</button>
          <button className="btn ghost" onClick={signOut}>Sign out</button>
        </div>
      </header>

      <main className="container">
        <section className="stats">
          <StatCard label="Total" value={counts.total} tone="brand" icon="📋" />
          <StatCard label="Submitted" value={counts.Submitted} tone="success" icon="✅" pct={pct(counts.Submitted)} />
          <StatCard label="Pending" value={counts.Pending} tone="warn" icon="⏳" pct={pct(counts.Pending)} />
          <StatCard label="Late" value={counts.Late} tone="danger" icon="⚠️" pct={pct(counts.Late)} />
        </section>

        <section className="filters glass">
          <div className="filter-group">
            <label className="muted small">Subject</label>
            <div className="chips">
              <Chip active={filter === 'All'} onClick={() => setFilter('All')}>All</Chip>
              {subjects.map((s) => (
                <Chip key={s} active={filter === s} onClick={() => setFilter(s)}>{s}</Chip>
              ))}
            </div>
          </div>
          <div className="filter-group">
            <label className="muted small">Status</label>
            <div className="chips">
              {['All', 'Submitted', 'Pending', 'Late'].map((s) => (
                <Chip key={s} active={statusFilter === s} onClick={() => setStatusFilter(s)} tone={s.toLowerCase()}>
                  {s}
                </Chip>
              ))}
            </div>
          </div>
        </section>

        <section className="list">
          {filtered.length === 0 ? (
            <div className="empty glass">
              <div className="empty-icon">🗂️</div>
              <h3>No assignments yet</h3>
              <p className="muted">Add your first assignment to start tracking submissions.</p>
              <button className="btn primary" onClick={() => setShowForm(true)}>+ Add Assignment</button>
            </div>
          ) : (
            filtered.map((a) => (
              <AssignmentCard key={a.id} a={a} onStatus={setStatus} onRemove={remove} />
            ))
          )}
        </section>
      </main>

      {showForm && (
        <Modal onClose={() => setShowForm(false)} title="New Assignment">
          <form onSubmit={addAssignment} className="form">
            <label className="field">
              <span>Title</span>
              <input
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
                required placeholder="e.g. Data Structures Lab 4"
              />
            </label>
            <label className="field">
              <span>Subject</span>
              <input
                value={form.subject}
                onChange={(e) => setForm({ ...form, subject: e.target.value })}
                required placeholder="e.g. CS201"
                list="subject-suggestions"
              />
              <datalist id="subject-suggestions">
                {subjects.map((s) => <option key={s} value={s} />)}
              </datalist>
            </label>
            <label className="field">
              <span>Due date</span>
              <input
                type="date"
                value={form.dueDate}
                onChange={(e) => setForm({ ...form, dueDate: e.target.value })}
                required
              />
            </label>
            <div className="row gap end">
              <button type="button" className="btn ghost" onClick={() => setShowForm(false)}>Cancel</button>
              <button type="submit" className="btn primary">Create</button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}

function StatCard({ label, value, tone, icon, pct }) {
  return (
    <div className={`stat glass tone-${tone}`}>
      <div className="stat-top">
        <span className="stat-icon">{icon}</span>
        <span className="stat-label">{label}</span>
      </div>
      <div className="stat-value">{value}</div>
      {typeof pct === 'number' && (
        <div className="bar"><div className="bar-fill" style={{ width: `${pct}%` }} /></div>
      )}
    </div>
  );
}

function Chip({ children, active, onClick, tone }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`chip ${active ? 'active' : ''} ${tone ? `chip-${tone}` : ''}`}
    >
      {children}
    </button>
  );
}

function AssignmentCard({ a, onStatus, onRemove }) {
  const toneClass = a.computed === 'Submitted' ? 'success' : a.computed === 'Late' ? 'danger' : 'warn';
  const days = Math.ceil((new Date(a.dueDate) - new Date(today())) / (1000 * 60 * 60 * 24));
  const dueLabel =
    a.computed === 'Submitted'
      ? 'Submitted'
      : days === 0 ? 'Due today' : days > 0 ? `Due in ${days}d` : `${Math.abs(days)}d overdue`;

  return (
    <article className={`card glass tone-${toneClass}`}>
      <div className="card-main">
        <div className="row between top">
          <div>
            <div className="row gap small">
              <span className="badge subject">{a.subject}</span>
              <span className={`badge status status-${toneClass}`}>{a.computed}</span>
            </div>
            <h3 className="title">{a.title}</h3>
            <p className="muted small">📅 {new Date(a.dueDate).toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' })} · {dueLabel}</p>
          </div>
          <button className="iconbtn" onClick={() => onRemove(a.id)} title="Delete">✕</button>
        </div>
        <div className="row gap wrap">
          <button
            className={`btn small ${a.status === 'Submitted' ? 'success' : 'ghost'}`}
            onClick={() => onStatus(a.id, 'Submitted')}
          >✅ Submitted</button>
          <button
            className={`btn small ${a.status === 'Pending' ? 'warn' : 'ghost'}`}
            onClick={() => onStatus(a.id, 'Pending')}
          >⏳ Pending</button>
          <button
            className={`btn small ${a.status === 'Late' ? 'danger' : 'ghost'}`}
            onClick={() => onStatus(a.id, 'Late')}
          >⚠️ Late</button>
        </div>
      </div>
    </article>
  );
}

function Modal({ children, title, onClose }) {
  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal glass" onClick={(e) => e.stopPropagation()}>
        <div className="row between">
          <h2>{title}</h2>
          <button className="iconbtn" onClick={onClose}>✕</button>
        </div>
        {children}
      </div>
    </div>
  );
}
