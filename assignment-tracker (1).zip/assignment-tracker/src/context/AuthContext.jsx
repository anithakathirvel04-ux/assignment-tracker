import { createContext, useContext, useEffect, useState } from 'react';

const AuthContext = createContext(null);
const USERS_KEY = 'ast_users';
const SESSION_KEY = 'ast_session';

// tiny hash so we don't store plaintext passwords in localStorage
const hash = (s) => {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
  return String(h);
};

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const s = localStorage.getItem(SESSION_KEY);
    if (s) setUser(JSON.parse(s));
  }, []);

  const getUsers = () => JSON.parse(localStorage.getItem(USERS_KEY) || '{}');
  const saveUsers = (u) => localStorage.setItem(USERS_KEY, JSON.stringify(u));

  const signUp = ({ name, email, password }) => {
    const users = getUsers();
    const key = email.toLowerCase().trim();
    if (users[key]) throw new Error('An account with this email already exists.');
    users[key] = { name, email: key, password: hash(password) };
    saveUsers(users);
    const session = { name, email: key };
    localStorage.setItem(SESSION_KEY, JSON.stringify(session));
    setUser(session);
  };

  const signIn = ({ email, password }) => {
    const users = getUsers();
    const key = email.toLowerCase().trim();
    const u = users[key];
    if (!u || u.password !== hash(password)) throw new Error('Invalid email or password.');
    const session = { name: u.name, email: u.email };
    localStorage.setItem(SESSION_KEY, JSON.stringify(session));
    setUser(session);
  };

  const signOut = () => {
    localStorage.removeItem(SESSION_KEY);
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, signUp, signIn, signOut }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
